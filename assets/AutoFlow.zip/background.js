// background.js — AutoFlow v3

const QUEUE_KEY = "fa_queue_v3";

const saveQueue = q  => new Promise(r => chrome.storage.local.set({ [QUEUE_KEY]: q }, r));
const loadQueue = () => new Promise(r => chrome.storage.local.get(QUEUE_KEY, d => r(d[QUEUE_KEY] || null)));
const clearQueue = () => new Promise(r => chrome.storage.local.remove(QUEUE_KEY, r));

chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
chrome.action.onClicked.addListener(tab => chrome.sidePanel?.open({ tabId: tab.id }).catch(() => {}));
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ imageCount: 1 });
});

// Google moved Flow off labs.google/fx/tools/flow onto its own flow.google
// domain (Sep 2026), which actually resolves as flow.google.com (and may use
// locale subdomains). Some users are still redirected through/keep tabs open
// on the old labs.google host, so all of these are matched here.
function isFlowUrl(url) {
  if (!url) return false;
  let host;
  try { host = new URL(url).hostname; } catch { return false; }
  // Matches: flow.google, flow.google.com, *.flow.google, *.flow.google.com
  if (/(^|\.)flow\.google(\.com)?$/i.test(host)) return true;
  if ((host === "labs.google" || host.endsWith(".labs.google")) && url.includes("flow")) return true;
  return false;
}
function getFlowTab() {
  return new Promise(r => {
    chrome.tabs.query({}, tabs => {
      r((tabs||[]).find(t => isFlowUrl(t.url)) || null);
    });
  });
}
function extractProjectId(url) {
  const m = url?.match(/\/project\/([a-zA-Z0-9_-]{8,})/);
  return m ? m[1] : null;
}
async function checkConnection() {
  const tab = await getFlowTab();
  if (!tab) return { status:"disconnected", flowTabId:null, hasProject:false, projectId:null };
  const projectId = extractProjectId(tab.url);
  return { status:"connected", flowTabId:tab.id, hasProject:!!projectId, projectId, tabUrl:tab.url };
}
async function injectAntiThrottle(tabId) {
  try { await chrome.scripting.executeScript({ target:{tabId}, files:["alwaysActive.js"], world:"MAIN" }); }
  catch(e) {}
}

// ── MAIN-world task functions ──────────────────────────────────────
// These run directly inside the Flow page via chrome.scripting.executeScript's
// `func` parameter. They must be real, self-contained function declarations
// (no closures over outer scope) — NOT built from strings — because Flow's
// page CSP now enforces Trusted Types, which blocks eval()/new Function()
// executed inside the page's own JS realm. Passing real functions to
// executeScript's `func` sidesteps that entirely.

async function mainWorldInjectPrompt(text) {
  try {
    // Google's Sep 2026 redesign replaced the old Slate.js/React editor with
    // a ProseMirror editor wrapped in an Angular custom element:
    // <flow-rich-text-editor> > .prosemirror-editor > [contenteditable] > <p>
    function findEditorEl() {
      // Prefer the editor scoped to the prompt composer specifically.
      let el = document.querySelector('[class*="prompt-input"] flow-rich-text-editor [contenteditable="true"]');
      if (el) return el;
      el = document.querySelector('flow-rich-text-editor .prosemirror-editor [contenteditable="true"]');
      if (el) return el;
      const all = Array.from(document.querySelectorAll(
        'flow-rich-text-editor [contenteditable="true"], .ProseMirror[contenteditable="true"], [contenteditable="true"]'
      ));
      // The compose box is typically the last contenteditable in DOM order
      // (project-title/rename fields, if any, tend to appear earlier).
      return all[all.length - 1] || null;
    }
    function selectAllContent(el) {
      const range = document.createRange();
      range.selectNodeContents(el);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    }
    function readText(el) { return (el.textContent || '').trim(); }
    function looksInserted(el, text) {
      const got = readText(el);
      return !!got && (got === text.trim() || got.includes(text.substring(0, Math.min(30, text.length))));
    }
    const wait = ms => new Promise(r => setTimeout(r, ms));

    const el = findEditorEl();
    if (!el) return { success: false, error: 'Editor not found' };

    el.focus(); el.click();

    // IMPORTANT: ProseMirror (and similar model-driven editors) keeps its own
    // internal document state. A raw DOM mutation that doesn't go through the
    // editor's normal input pipeline can appear to succeed for an instant,
    // then get silently wiped when the editor reconciles the DOM back to its
    // (unaware) internal state a beat later. So every strategy below is
    // checked for PERSISTENCE after a short delay, not just immediately.

    // 1) Type character-by-character via execCommand — this fires a real
    //    beforeinput/input event per character, matching genuine keystroke
    //    input, which is the one input path every rich-text editor is
    //    guaranteed to handle correctly (unlike a single bulk paste, which
    //    some editors' paste handlers special-case or reject).
    try {
      selectAllContent(el);
      document.execCommand('delete', false, null);
      for (const ch of text) {
        document.execCommand('insertText', false, ch);
      }
      await wait(300);
      if (looksInserted(el, text)) return { success: true };
    } catch (_) {}

    // 2) Native clipboard paste — some editors only wire up their own paste
    //    handler and ignore manual execCommand insertion.
    try {
      selectAllContent(el);
      const dt = new DataTransfer();
      dt.setData('text/plain', text);
      el.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt }));
      await wait(300);
      if (looksInserted(el, text)) return { success: true };
    } catch (_) {}

    // 3) Last resort: single bulk execCommand insertText.
    try {
      selectAllContent(el);
      document.execCommand('insertText', false, text);
      await wait(300);
      if (looksInserted(el, text)) return { success: true };
    } catch (_) {}

    return { success: false, error: 'Text did not persist in the editor (the page reverted it) — try a different insertion method' };
  } catch (e) {
    return { success: false, error: String(e?.message || e) };
  }
}

async function mainWorldClickSubmit() {
  try {
    function isVisible(node) {
      const r = node.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    }
    function findEditorEl() {
      return document.querySelector(
        '[class*="prompt-input"] flow-rich-text-editor [contenteditable="true"], flow-rich-text-editor .prosemirror-editor [contenteditable="true"], [contenteditable="true"]'
      );
    }
    function findSubmitButton() {
      const candidates = Array.from(document.querySelectorAll('button, [role="button"]'))
        .filter(b => !b.disabled && b.getAttribute('aria-disabled') !== 'true' && isVisible(b));

      const labelRe = /(generate|create image|create video|submit|send)\b/i;
      const iconRe = /(arrow_forward|arrow_right_alt|east|send|play_arrow)/i;

      let match = candidates.find(b => labelRe.test(b.getAttribute('aria-label') || ''));
      if (match) return match;

      match = candidates.find(b => {
        const iconEl = b.querySelector('i, [class*="material"], [class*="icon"]');
        return iconEl && iconRe.test((iconEl.textContent || iconEl.className || '').toString());
      });
      if (match) return match;

      // Fall back to the interactive control closest to the prompt editor —
      // walk up from the editor, widening scope, and take the last button
      // found within that scope (the submit control is usually last in the
      // composer's DOM order).
      const editor = findEditorEl();
      let scope = editor ? (editor.closest('[class*="prompt"], [class*="input"], form') || editor.parentElement) : null;
      for (let hops = 0; hops < 6 && scope; hops++) {
        const within = candidates.filter(b => scope.contains(b));
        if (within.length) return within[within.length - 1];
        scope = scope.parentElement;
      }
      return candidates[candidates.length - 1] || null;
    }
    function fireFullClick(node) {
      const r = node.getBoundingClientRect();
      const x = r.left + r.width / 2, y = r.top + r.height / 2;
      const opts = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y };
      ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(type => {
        try {
          const Ev = type.startsWith('pointer') && typeof PointerEvent !== 'undefined' ? PointerEvent : MouseEvent;
          node.dispatchEvent(new Ev(type, opts));
        } catch (_) {}
      });
    }
    function fireEnterKey(node) {
      const opts = { bubbles: true, cancelable: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13 };
      node.dispatchEvent(new KeyboardEvent('keydown', opts));
      node.dispatchEvent(new KeyboardEvent('keypress', opts));
      node.dispatchEvent(new KeyboardEvent('keyup', opts));
    }
    const editorEl = findEditorEl();
    let firedSomething = false;

    // Fire Enter-key submit — many chat-style prompt boxes submit on Enter.
    if (editorEl) {
      editorEl.focus();
      fireEnterKey(editorEl);
      firedSomething = true;
    }

    // Also fire a real click on the submit button, if one is found.
    const btn = findSubmitButton();
    if (btn) {
      try { btn.click(); } catch (_) {}
      fireFullClick(btn);

      // Fallback for any remaining React-managed controls: invoke onClick
      // via the fiber tree directly (same technique the pre-redesign UI
      // needed).
      try {
        const fk = Object.keys(btn).find(k => k.startsWith('__reactFiber') || k.startsWith('__reactInternalInstance'));
        if (fk) {
          let n = btn[fk], fn = null;
          for (let i = 0; i < 50 && n; i++) {
            const p = n.memoizedProps;
            if (p && typeof p.onClick === 'function') { fn = p.onClick; break; }
            n = n.return;
          }
          if (fn) {
            fn({
              isTrusted: true, type: 'click', bubbles: true, cancelable: true,
              target: btn, currentTarget: btn,
              nativeEvent: { isTrusted: true, type: 'click', target: btn },
              isDefaultPrevented: () => false, isPropagationStopped: () => false,
              preventDefault: () => {}, stopPropagation: () => {}
            });
          }
        }
      } catch (_) {}
      firedSomething = true;
    }

    if (!firedSomething) return { success: false, error: 'Could not find the prompt box or a submit button' };

    // NOTE: we deliberately don't verify success by re-reading the editor's
    // DOM state afterward. In testing, that check was unreliable — Angular's
    // own re-render of <flow-rich-text-editor> after a real submit doesn't
    // consistently match what a fresh querySelector sees, which produced
    // false "still in box" failures even when the prompt had genuinely been
    // submitted and was already generating. Firing Enter + a full click
    // sequence has proven reliable in practice, so we trust it.
    return { success: true };
  } catch (e) {
    return { success: false, error: String(e?.message || e) };
  }
}
function broadcast(msg) { chrome.runtime.sendMessage(msg).catch(() => {}); }
function sendToContent(tabId, message, timeoutMs = 210000) {
  return new Promise(resolve => {
    const timer = setTimeout(() => resolve({ ok:false, error:"timeout" }), timeoutMs);
    try {
      chrome.tabs.sendMessage(tabId, message, res => {
        clearTimeout(timer);
        if (chrome.runtime.lastError) {}
        resolve(res || { ok:true });
      });
    } catch(e) { clearTimeout(timer); resolve({ ok:false, error:e.message }); }
  });
}

let stopFlag = false;
let currentFlowTabId = null;
let pausedIndex = -1;

const sleep = ms => new Promise(r => setTimeout(r, ms));

// Reset stuck running items back to pending
async function resetRunningItems() {
  const q = await loadQueue();
  if (!q?.items) return;
  let changed = false;
  q.items = q.items.map(item => {
    if (item.status === "running") {
      changed = true;
      return { ...item, status: "pending" };
    }
    return item;
  });
  if (changed) await saveQueue({ ...q, runningId: null });
}

// ── Queue item statuses: pending | running | done | skipped | error ──
// Queue shape: { items: [{id,prompt,status,addedAt}], settings, runningId }

async function runQueue(tabId, fromId = null) {
  stopFlag = false;
  currentFlowTabId = tabId;
  await injectAntiThrottle(tabId);
  await resetRunningItems();

  const q = await loadQueue();
  if (!q) { broadcast({ type:"NO_QUEUE" }); return; }

  // Find starting point
  let items = q.items;
  let startIdx = 0;
  if (fromId) {
    const idx = items.findIndex(x => x.id === fromId);
    if (idx >= 0) startIdx = idx;
  } else {
    // Find first pending
    startIdx = items.findIndex(x => x.status === "pending");
    if (startIdx < 0) { broadcast({ type:"BATCH_DONE", total: items.length }); return; }
  }

  const total = items.length;

  for (let i = startIdx; i < total; i++) {
    const q2 = await loadQueue();
    if (!q2) return;
    items = q2.items;

    if (stopFlag) {
      broadcast({ type:"BATCH_PAUSED" });
      return;
    }

    const item = items[i];
    if (!item) continue;
    if (item.status === "done" || item.status === "skipped") continue;
    if (item.status === "paused") {
      broadcast({ type:"ITEM_PAUSED", id: item.id });
      continue;
    }

    // Mark running
    items[i] = { ...item, status: "running" };
    await saveQueue({ ...q2, items, runningId: item.id });
    broadcast({ type:"QUEUE_UPDATE", items });
    broadcast({ type:"BATCH_PROGRESS", current: i+1, total, prompt: item.prompt, id: item.id });

    const result = await sendToContent(tabId, {
      action: "createimage",
      prompt: item.prompt,
      imageCount: q2.settings.imageCount || 1,
    });

    // Reload queue (user may have changed it while running)
    const q3 = await loadQueue();
    if (!q3) return;
    const freshIdx = q3.items.findIndex(x => x.id === item.id);
    if (freshIdx >= 0) {
      q3.items[freshIdx] = {
        ...q3.items[freshIdx],
        status: result?.ok ? "done" : "error",
        error: result?.ok ? null : (result?.error || "Unknown error"),
        doneAt: result?.ok ? Date.now() : null
      };
      await saveQueue({ ...q3, runningId: null });
      broadcast({ type:"QUEUE_UPDATE", items: q3.items });
      if (result?.ok) {
        broadcast({ type:"ITEM_DONE", id: item.id });
      } else {
        // Stop the batch on the first failure instead of silently burning
        // through the rest of the queue — surface the real error so it's
        // obvious something (e.g. a page selector) needs fixing.
        broadcast({ type:"ITEM_ERROR", id: item.id, error: q3.items[freshIdx].error });
        broadcast({ type:"BATCH_ERROR", error: q3.items[freshIdx].error, prompt: item.prompt });
        return;
      }
    }

    if (stopFlag) {
      broadcast({ type:"BATCH_PAUSED" });
      return;
    }

    // Check if there are more pending items
    const q4 = await loadQueue();
    if (!q4) return;
    const nextPending = q4.items.slice(i + 1).find(x => x.status === "pending");
    if (!nextPending) break;

    // Exact delay — no randomness
    const delayMs = Math.max(0, (q4.settings.delaySec ?? 3)) * 1000;
    broadcast({ type:"COUNTDOWN_START", delayMs });
    const end = Date.now() + delayMs;
    while (Date.now() < end && !stopFlag) {
      broadcast({ type:"COUNTDOWN_TICK", msLeft: end - Date.now() });
      await sleep(200);
    }
  }

  const qf = await loadQueue();
  const allDone = qf?.items.every(x => x.status === "done" || x.status === "skipped");
  broadcast({ type:"BATCH_DONE", total: qf?.items.length || 0, allDone });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "PING") { sendResponse({ pong:true }); return false; }

  if (msg.type === "CHECK_CONNECTION") {
    checkConnection().then(s => sendResponse({ state:s })).catch(() => sendResponse({ state:{status:"disconnected"} }));
    return true;
  }
  if (msg.type === "GET_FLOW_TAB") {
    getFlowTab().then(tab => sendResponse({ tab }));
    return true;
  }

  if (msg.type === "START_QUEUE") {
    sendResponse({ ok:true });
    getFlowTab().then(tab => {
      if (!tab) { broadcast({ type:"ERROR", msg:"Flow tab not found" }); return; }
      runQueue(tab.id, msg.fromId).catch(console.error);
    });
    return false;
  }
  if (msg.type === "STOP_QUEUE") {
    stopFlag = true;
    if (currentFlowTabId) chrome.tabs.sendMessage(currentFlowTabId, { action:"stopProcessing" }).catch(() => {});
    sendResponse({ ok:true });
    return false;
  }

  // Queue CRUD
  if (msg.type === "GET_QUEUE") {
    loadQueue().then(q => sendResponse({ queue:q }));
    return true;
  }
  if (msg.type === "SAVE_QUEUE") {
    saveQueue(msg.queue).then(() => sendResponse({ ok:true }));
    return true;
  }
  if (msg.type === "CLEAR_QUEUE") {
    clearQueue().then(() => sendResponse({ ok:true }));
    return true;
  }
  if (msg.type === "UPDATE_ITEM_STATUS") {
    loadQueue().then(async q => {
      if (!q) { sendResponse({ ok:false }); return; }
      const idx = q.items.findIndex(x => x.id === msg.id);
      if (idx >= 0) {
        q.items[idx] = { ...q.items[idx], status: msg.status };
        await saveQueue(q);
        broadcast({ type:"QUEUE_UPDATE", items: q.items });
      }
      sendResponse({ ok:true });
    });
    return true;
  }

  // MAIN world execution — dispatches to real, statically-defined functions
  // (never eval/new Function, so it isn't blocked by the page's Trusted Types CSP)
  if (msg.action === "runMainWorldTask") {
    const tabId = sender.tab?.id;
    if (!tabId) { sendResponse({ success:false, error:"No tab ID" }); return false; }
    const taskFn = msg.task === "injectPrompt" ? mainWorldInjectPrompt
                 : msg.task === "clickSubmit"  ? mainWorldClickSubmit
                 : null;
    if (!taskFn) { sendResponse({ success:false, error:"Unknown task: " + msg.task }); return false; }
    chrome.scripting.executeScript({
      target:{tabId}, world:"MAIN",
      func: taskFn,
      args: msg.args || [],
    }).then(results => {
      const r = results?.[0]?.result;
      sendResponse(r || { success:false, error:"No result" });
    }).catch(e => sendResponse({ success:false, error:String(e?.message||e) }));
    return true;
  }
});
