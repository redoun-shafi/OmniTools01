// flowContentScript.js — DOM automation for Google Flow (AutoFlow)
// Uses exact same techniques as the original extension. Created with love by Redoun.

(() => {
  let isProcessing = false;
  let stopRequested = false;
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  function runMainWorldTask(task, args = []) {
    return new Promise(resolve => {
      chrome.runtime.sendMessage({ action: "runMainWorldTask", task, args }, res => {
        if (chrome.runtime.lastError) resolve({ success: false, error: chrome.runtime.lastError.message });
        else resolve(res || { success: false, error: "No response" });
      });
    });
  }

  // ── Inject text into Slate.js (logic runs in background.js as a real
  //    function — no eval/new Function, so it works under Trusted Types) ─
  async function injectPrompt(text) {
    const result = await runMainWorldTask("injectPrompt", [text]);
    if (!result.success) throw new Error("Inject failed: " + (result.error || "unknown"));
  }

  // ── Click submit via React fiber onClick ─
  async function clickSubmit() {
    const result = await runMainWorldTask("clickSubmit");
    if (!result.success) throw new Error("Submit failed: " + (result.error || "unknown"));
  }

  // ── Main handler — inject prompt and submit immediately, no waits ─
  async function handleCreateImage(req, sendResponse) {
    if (isProcessing) { sendResponse({ ok: false, error: "busy" }); return; }
    isProcessing = true;
    stopRequested = false;
    try {
      await injectPrompt(req.prompt);
      await clickSubmit();
      // No generation wait — AI takes whatever time it needs.
      // All inter-prompt delay is controlled by the user via frontend settings.
      sendResponse({ ok: true });
    } catch (e) {
      console.error("[AutoFlow]", e.message);
      sendResponse({ ok: false, error: e.message });
    } finally {
      isProcessing = false;
    }
  }

  chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (req.action === "createimage")    { handleCreateImage(req, sendResponse); return true; }
    if (req.action === "stopProcessing") { stopRequested = true; isProcessing = false; sendResponse({ ok: true }); return false; }
    if (req.action === "getPageState")   {
      const m = window.location.href.match(/\/project\/([a-zA-Z0-9_-]{8,})/);
      sendResponse({ url: window.location.href, hasProject: !!m, projectId: m?.[1] || null, isProcessing });
      return false;
    }
  });

  console.log("[AutoFlow] Ready. Created with love by Redoun.");
})();
